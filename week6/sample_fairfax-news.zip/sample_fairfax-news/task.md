

## Task

The included API endpoint returns, amongst other data, an array of news stories (assets).
You are tasked with creating an iPhone app that consumes the provided API and displays a list of news articles to the user, ideally in a TableView or CollectionView. Tapping a story should present the asset’s URL in a WKWebView.

## Requirements

* The list of articles should display at least the following fields:
-- headline
-- theAbstract
-- byLine

* If there are related images available for an asset, display the smallest image available for the asset in the cell also.
* Images should be loaded asynchronously

* The style of the cells is up to you.
* Use unit tests were applicable
* UI can be created using storyboards or in code, but should be adaptable to all iPhone screen sizes.
* Comment your code so it can be understood in six months
* We prefer Swift (3), however we want idiomatic code, use Objective-C if you're
   unfamiliar with Swift.

Please feel free to ask if you have any questions when interpreting this
document!

## How we evaluate

We want you to succeed! We aim to evaluate each submission with the same
criteria, they are:

 * *requirements* you've done what we asked you to
 * *code architecture* appropriate patterns, structure, etc.
 * *code style* idiomatic, safe, clean, concise etc.
 * *testability* architecture, design, dependencies, etc.
 * *user experience* responsive, user-centric design, etc.

## Resources

API Endpoint:
https://bruce-v2-mob.fairfaxmedia.com.au/1/coding_test/13ZZQX/full
