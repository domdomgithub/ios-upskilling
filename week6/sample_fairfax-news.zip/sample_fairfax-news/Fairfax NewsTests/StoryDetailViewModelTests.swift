//
//  StoryDetailViewModelTests.swift
//  Fairfax News
//
//  Created by Faiq Kazi on 20/8/17.
//  Copyright © 2017 Faiq Kazi. All rights reserved.
//

import XCTest

class StoryDetailViewModelTests: FairfaxTests {
    
    let fakeViewController = FakeViewController()
    
    func testViewModelLoadPageMethod() {
        
        let viewModel = StoryDetailViewModel(pageUrl: "http://dummyurl", screenTitle: "full story")
        viewModel.delegate = fakeViewController
        viewModel.viewDidLoad() // this will trigger refresh
        
        // Verify expected values at View Controller
        
        XCTAssertTrue(fakeViewController.errorMessage == "", "no error was expected here")
        XCTAssertNotNil(fakeViewController.pageUrl, "expected page url populated")
    }
}

// MARK: - class overrides; fakes, mock and test spy

extension StoryDetailViewModelTests {
    
    // this is Test Spy to verify expected values received by ViewController
    
    class FakeViewController: StoryDetailActions {
        
        var pageLoadStatus = false
        func pageLoading(status: Bool) {
            self.pageLoadStatus = status
        }
        
        var pageUrl: URLRequest?
        func loadUrl(_ url: URLRequest) {
            self.pageUrl = url
        }
        
        var errorMessage = ""
        func errorOccured(message: String) {
            self.errorMessage = message
        }
    }
}
