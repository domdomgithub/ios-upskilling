//
//  FairfaxTests.swift
//  Fairfax News
//
//  Created by Faiq Kazi on 20/8/17.
//  Copyright © 2017 Faiq Kazi. All rights reserved.
//

import XCTest

import OHHTTPStubs

class FairfaxTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
    }
    
    override func tearDown() {
        super.tearDown()
        
        OHHTTPStubs.removeAllStubs()
    }
    
}

class StubUtil {
    open static let sharedInstance = StubUtil()

    func createStubWithFile(_ fileName: String, path: String, host: String = "bruce-v2-mob.fairfaxmedia.com.au") -> OHHTTPStubsDescriptor {
        return stub(condition: isPath(path)) { (_) -> OHHTTPStubsResponse in
            let stubPath = OHPathForFile(fileName, type(of: self))
            return fixture(filePath: stubPath!, headers: ["Content-Type":"application/json; charset=utf-8"])
        }
    }    
}
