#!/bin/bash

SEARCH_PATH="${1:-./Stubs}"
MAX_DEPTH="${2:-1}"

for file in `find $SEARCH_PATH -name *.json -maxdepth $MAX_DEPTH`
do
  rm -f "$file"_temp
  python -m json.tool "$file" > "$file"_temp
  if [ -s "$file"_temp ]; then
    rm -f "$file"
    mv "$file"_temp "$file"
  else
    rm -f "$file"_temp
  fi
done
