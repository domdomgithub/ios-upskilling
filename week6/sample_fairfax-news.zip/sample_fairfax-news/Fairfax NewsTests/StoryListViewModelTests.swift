//
//  StoryListViewModelTests.swift
//  Fairfax News
//
//  Created by Faiq Kazi on 20/8/17.
//  Copyright © 2017 Faiq Kazi. All rights reserved.
//

import XCTest

@testable import Fairfax_News

class StoryListViewModelTests: FairfaxTests {
    
    let fakeViewController = FakeViewController()

    func testViewModelRefreshSucceed() {
        
        let viewModel = ViewModel(expectation: expectation(description: "viewmodel refresh trigger"),
                                  newsFeedService: MockedNewsFeedService())
        viewModel.delegate = fakeViewController
        viewModel.viewDidLoad() // this will trigger refresh
        
        self.waitForExpectations(timeout: 5) { _ in }
        
        // Verify cell view model count is right
        
        XCTAssertTrue(viewModel.modelCount == 14, "incorrect number of cell view models - \(viewModel.modelCount)")
        
        // Verify sort order is correct
        
        let modelFirst = viewModel.modelForIndex(0)
        XCTAssertTrue(modelFirst.headline == "Microsoft billionaire Paul Allen discovers wreckage of lost WWII warship USS Indianapolis which carried the atomic bomb", "incorrect model at index 0")

        let modelLast = viewModel.modelForIndex(13)
        XCTAssertTrue(modelLast.headline == "Dinner is served: take your pick from meal kits, heat-and-eats or private catering", "incorrect model at index 13")
        
        // Verify expected values at View Controller
        
        XCTAssertTrue(fakeViewController.errorMessage == "", "no error was expected here")
        XCTAssertNotNil(fakeViewController.updatedFeed, "expected news feed populated")
        XCTAssertTrue(fakeViewController.refreshFeedStatus == false, "expected refresh status off")
    }
    
    func testViewModelRefreshFailure() {
        
        // override new service to return error
        class FailedNewsFeedService: MockedNewsFeedService {
            override func feed(success: @escaping (AssetList) -> Void, failure: @escaping (NewsFeedError) -> Void) {
                failure(.invalidData(""))
            }
        }
        
        let viewModel = ViewModel(expectation: expectation(description: "viewmodel refresh trigger"),
                                  newsFeedService: FailedNewsFeedService())
        viewModel.delegate = fakeViewController
        viewModel.viewDidLoad() // this will trigger refresh
        
        self.waitForExpectations(timeout: 5) { _ in }
        
        // Verify cell view model count is right
        
        XCTAssertTrue(viewModel.modelCount == 0, "incorrect number of cell view models - \(viewModel.modelCount)")
        
        // Verify expected values at View Controller
        
        XCTAssertTrue(fakeViewController.errorMessage == "Sorry could not fetch news feed, please try later",
                      "error was expected here - \(fakeViewController.errorMessage)")
        XCTAssertNil(fakeViewController.updatedFeed, "expected news feed empty")
        XCTAssertTrue(fakeViewController.refreshFeedStatus == false, "expected refresh status off")
    }
    
    func testSmallestImageIsPicked() {
        
        let viewModel = ViewModel(expectation: expectation(description: "viewmodel refresh trigger"),
                                  newsFeedService: MockedNewsFeedService())
        viewModel.delegate = fakeViewController
        viewModel.viewDidLoad() // this will trigger refresh
        
        self.waitForExpectations(timeout: 5) { _ in }
        
        let model = viewModel.modelForIndex(0)
        if let assetImage = model.assetImage() {
            XCTAssertTrue(assetImage.id == 1024579268 || assetImage.id == 1024571691, "incorrect asset image chosen")
        }
        else {
            XCTFail("asset image was not expected nil")
        }
    }
}

// MARK: - class overrides; fakes, mock and test spy

extension StoryListViewModelTests {
    
    // overriding view model to hookup wait expectation for async refresh
    
    class ViewModel: StoryListViewModel {
        
        let refreshExecuted: XCTestExpectation
        
        init(expectation: XCTestExpectation, newsFeedService: NewsFeedService) {
            self.refreshExecuted = expectation
            super.init(newsFeedService: newsFeedService)
        }
        
        override func refreshSucceed(assetList: AssetList) {
            super.refreshSucceed(assetList: assetList)
            refreshExecuted.fulfill()
        }
        
        override func refreshFailed(error: NewsFeedError) {
            super.refreshFailed(error: error)
            refreshExecuted.fulfill()
        }
    }
    
    // overriding service to intercept and stub response api call
    
    class MockedNewsFeedService: NewsFeedService {
        override init() {
            let _ = StubUtil.sharedInstance.createStubWithFile("success_articlelist.json", path: "/1/coding_test/13ZZQX/full")
        }
        
        override func downloadImage(url: String, callback: @escaping (UIImage?) -> Void) {
            callback(UIImage())
        }
    }
    
    // this is Test Spy to verify expected values received by ViewController
    
    class FakeViewController: StoryListActions {
        
        var refreshFeedStatus = false
        func refreshingFeed(status: Bool) {
            self.refreshFeedStatus = status
        }
        
        var updatedFeed: [StoryListViewModel.NewsViewModel]?
        func updateNewsFeed(_ feed: [StoryListViewModel.NewsViewModel]) {
            self.updatedFeed = feed
        }
        
        var errorMessage = ""
        func errorOccured(message: String) {
            self.errorMessage = message
        }
    }
}
