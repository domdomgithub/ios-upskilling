
This Application architecture is design to scale; using SRP, 3rd party libraries where appropriate and stable unit tests


## Screen Design

Screen design is MVVM pattern with SRP in mind, each screen has 3 basic components
* ViewController:	this is view part of screen, interacting with user and reacting to updates
* ViewModel:		glue/brain, coordinator between View and Service
* Service + Models:	fetches data from external source (e.g network, location services)

The idea is to have most logic in ViewModel, keeping ViewController slim -- which is not reliable and reasonable to unit test.
Service is Dependency Injected to ViewModel so it can be overriden in unit tests to simulate different behaviours (success / error)


## Unit Tests

The screen design architecture supports reliable and stable unit tests.
Written unit tests are stable and fast, conforming to F.I.R.S.T principles. Unit tests don't manipulate UI or access Network (try unplug network and run the tests)


## 3rd Party Libraries used

* Alamofire and Alamofire Image: Network json and image handling
* ModelMapper: json dictionary to object mapping
* OHHTTPStubs: Intercepting and stubbing network API calls for unit tests


## How to compile

You need Xcode 8.3.3 / Swift 3. This project is compatible with iOS 9+

To Make Project you need to have CocoaPods 1.1.0+ installed (to install cocoapods please see https://cocoapods.org)
Once installed please issue 'pod install' command in Podfile directory

NOTE: As this solution is using cocoapods, please use workspace file to open


### Additional features of this App:

* Pull to Refresh
* Async Image download and caching
* Smallest image is fetched for thumbnails
* Latest news at the top
* Loading spinner for content load
