#!/bin/sh

# syntax: sh bundle.sh
#
# purpose: compiles and caches ruby gem packages for bundler
#

BUNDLE_DIRECTORY=`dirname $0`/build/bundle
CACHE_PATH="${HOME}/buildcache/ios"
BUNDLE_VERSION_COMPILE=`bundle version | cut -d' ' -f3`

CACHE_TOOLCHAIN_SUFFIX=`ruby -v | cut -d' ' -f2`

function bundle_cache_path {
	resolved_gemfile=`shasum Gemfile.lock | cut -d' ' -f1`
	cache_key="bundler_${BUNDLE_VERSION_COMPILE}_Ruby-${CACHE_TOOLCHAIN_SUFFIX}_${resolved_gemfile}"
	echo "${CACHE_PATH}/${cache_key}"
}

function cacheStore {
	cache_store_path="$(bundle_cache_path)"

	echo "(bundler) storing to ${cache_store_path}"

	cp ./Gemfile.lock "${BUNDLE_DIRECTORY}"
	rm -rf "${cache_store_path}"
	mkdir -p "${CACHE_PATH}"

 	cp -R "${BUNDLE_DIRECTORY}" "${cache_store_path}"
 	cp -R .bundle "${cache_store_path}"
}

function cleanCompile {
	echo "(bundler) compling for Ruby ${CACHE_TOOLCHAIN_SUFFIX}..."
	rm -rf .bundle ~/.bundle "${BUNDLE_DIRECTORY}"
	set -e

	# use native nokogiri libraries
	bundle config build.nokogiri --use-system-libraries --with-xml2-include=/usr/include/libxml2 --with-xml2-lib=/usr/lib/

	# install gem packages mentioned in Gemfile
	bundle install --path build/bundle
}

function cacheRestore {
	cache_restore_path="$(bundle_cache_path)"

	echo "(bundler) restoring from ${cache_restore_path}"

	mkdir -p "${BUNDLE_DIRECTORY}"
	rm -rf "${BUNDLE_DIRECTORY}"

	cp -R "${cache_restore_path}" "${BUNDLE_DIRECTORY}"
	mv "${BUNDLE_DIRECTORY}/.bundle" ./
}

function hasCachedAlready {
	if [ ! -f Gemfile.lock ]; then
		echo "no"
	else
		cache_restore_path="$(bundle_cache_path)"

		if [ -d "${cache_restore_path}" ]; then
			echo "yes"
		else
			echo "no"
		fi
	fi
}

rm -rf .bundle "${BUNDLE_DIRECTORY}"

if [[ "$(hasCachedAlready)" == "yes" ]]; then
	cacheRestore
	echo "already upto date"	
else
	cleanCompile
	if [ $? -ne 0 ]; then
		exit $?
	fi	
	cacheStore
fi
