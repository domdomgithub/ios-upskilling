//
//  StoryDetailViewModel.swift
//  Fairfax News
//
//  Created by Faiq Kazi on 19/8/17.
//  Copyright © 2017 Faiq Kazi. All rights reserved.
//

import Foundation

// callbacks for view controller
protocol StoryDetailActions {
    func pageLoading(status: Bool)
    func loadUrl(_ url: URLRequest)
    func errorOccured(message: String)
}

class StoryDetailViewModel {
    
    let pageUrl: String
    let screenTitle: String
    
    var delegate: StoryDetailActions?
    
    init(pageUrl: String, screenTitle: String) {
        self.pageUrl = pageUrl
        self.screenTitle = screenTitle
    }
    
    func loadPage() {
        delegate?.pageLoading(status: true)
        
        let requestURL = NSURL(string: self.pageUrl)
        delegate?.loadUrl(URLRequest.init(url: requestURL! as URL))
    }
    
    // MARK: -
    
    public func viewDidLoad() {
        self.loadPage()
    }
    
    public func pageWillLoad() {
        delegate?.pageLoading(status: true)
    }
    
    public func pageDidLoad() {
        delegate?.pageLoading(status: false)
    }
    
    public func pageDidTerminate() {
        delegate?.pageLoading(status: false)
        delegate?.errorOccured(message: "Couldn't fetch content unexpectedly, please try again later")
    }
    
    public func pageLoadError(_ error: Error) {
        delegate?.pageLoading(status: false)
        delegate?.errorOccured(message: "Couldn't fetch content, please try again later")
    }
    
}
