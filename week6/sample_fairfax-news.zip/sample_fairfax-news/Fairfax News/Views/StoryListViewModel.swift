//
//  StoryListViewModel.swift
//  Fairfax News
//
//  Created by Faiq Kazi on 19/8/17.
//  Copyright © 2017 Faiq Kazi. All rights reserved.
//

import Foundation

import UIKit // for UIImage definition

// callbacks for view controller
protocol StoryListActions {
    func refreshingFeed(status: Bool)
    func updateNewsFeed(_ feed: [StoryListViewModel.NewsViewModel])
    func errorOccured(message: String)
}

class StoryListViewModel {
    
    internal var newsFeedService: NewsFeedService
    
    var delegate: StoryListActions?
    
    internal var cellViewModels = [NewsViewModel]()
    
    /** service depedency inversion, apart being modular design this DI helps Unit Testing
     */
    init(newsFeedService: NewsFeedService = NewsFeedService.sharedInstance) {
        self.newsFeedService = newsFeedService
    }
    
    func viewDidLoad() {
        self.refresh()
    }
    
    func refresh() {
        self.delegate?.refreshingFeed(status: true)
        
        self.newsFeedService.feed(success: { [weak self] (assetList) in
            guard let strongSelf = self else { return }
            
            strongSelf.refreshSucceed(assetList: assetList)
            
        }) { [weak self] (error) in
            debugPrint(error.localizedDescription)
            guard let strongSelf = self else { return }
            
            strongSelf.refreshFailed(error: error)
        }
    }
    
    internal func refreshSucceed(assetList: AssetList) {
        self.delegate?.refreshingFeed(status: false)
        
        // convert network Model to View Model suitable for screen
        let cellViewModels = assetList.assets.map { (article) -> NewsViewModel in
            NewsViewModel(article: article)
        }
        // sort latest news to the top
        let sortedCellViewModels = cellViewModels.sorted(by: { $0.date.compare($1.date) == .orderedDescending})
        
        self.cellViewModels = sortedCellViewModels
        self.delegate?.updateNewsFeed(self.cellViewModels)
    }
    
    internal func refreshFailed(error: NewsFeedError) {
        self.delegate?.refreshingFeed(status: false)
        self.delegate?.errorOccured(message: "Sorry could not fetch news feed, please try later")
    }
    
    func modelForIndex(_ index: Int) -> NewsViewModel {
        let viewModel = self.cellViewModels[index]
        return viewModel
    }
    
    var modelCount: Int {
        return self.cellViewModels.count
    }
    
    /** NewsViewModel represents cell on story list
     */
    class NewsViewModel {
        fileprivate let article: AssetArticle
        
        internal var newsFeedService: NewsFeedService
        
        fileprivate init(article: AssetArticle, newsFeedService: NewsFeedService = NewsFeedService.sharedInstance) {
            self.article = article
            self.newsFeedService = newsFeedService
        }
        
        var headline: String {
            return self.article.headline
        }
        
        var abstract: String {
            return self.article.theAbstract
        }
        
        var line: String {
            return self.article.byLine
        }

        var date: Date {
            return Date(timeIntervalSince1970: self.article.timeStamp)
        }
        
        var url: String {
            return self.article.url
        }
        
        var hasImage: Bool {
            return self.article.relatedImages.count > 0
        }
        
        /** finds smallest asset image to display as thumbnail
        */
        internal func assetImage() -> AssetImage? {
            var thumbnailAsset: AssetImage?
            for relatedImage in article.relatedImages {
                if relatedImage.width == 0 { // filter out any invalids
                    continue
                }
                if relatedImage.width < (thumbnailAsset?.width ?? Int.max) {
                    thumbnailAsset = relatedImage
                }
            }
            return thumbnailAsset
        }
        
        func downloadImage(callback: @escaping (UIImage?) -> Void) {
            guard let assetImage = self.assetImage() else {
                callback(nil) // error
                return
            }
            newsFeedService.downloadImage(url: assetImage.url) { (image) in
                callback(image)
            }
        }
    }
}
