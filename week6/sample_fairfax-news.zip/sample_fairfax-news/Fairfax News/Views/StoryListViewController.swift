//
//  StoryTableViewController.swift
//  Fairfax News
//
//  Created by Faiq Kazi on 19/8/17.
//  Copyright © 2017 Faiq Kazi. All rights reserved.
//

import UIKit

class StoryListViewController: UITableViewController {

    internal var viewModel = StoryListViewModel()
    internal let spinner = Spinner()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.dataSource = self
        self.tableView.delegate = self

        self.viewModel.delegate = self
        self.viewModel.viewDidLoad()
        
        // remove back button text from navigation controller, keeping back button clean
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
        
        self.setupPullToRefresh()
    }
    
    internal func setupPullToRefresh() {
        
        self.refreshControl = UIRefreshControl()
        
        // set up spinner color
        let color = UIColor(red:0.25, green:0.72, blue:0.85, alpha:1.0)
        self.refreshControl?.tintColor = color
        
        // set up information text under the spinner
        let displayString = "Fetching News ..."
        let attributedString = NSMutableAttributedString(string: displayString)
        attributedString.addAttribute(NSForegroundColorAttributeName, value: color, range: NSMakeRange(0, displayString.characters.count))
        self.refreshControl?.attributedTitle = attributedString

        self.refreshControl?.addTarget(self, action: #selector(refresh(_:)), for: .valueChanged)
        
        // add refresh control to table view
        if #available(iOS 10.0, *) {
            tableView.refreshControl = refreshControl
        } else {
            tableView.addSubview(self.refreshControl!)
        }
    }
    
    @objc private func refresh(_ sender: Any) {
        self.viewModel.refresh()
    }

    // MARK: - Table view data source/delegates

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.modelCount
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NewsFeedCell", for: indexPath) as! NewsFeedTableViewCell

        let cellViewModel = self.viewModel.modelForIndex(indexPath.row)
        cell.configure(viewModel: cellViewModel)

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = self.viewModel.modelForIndex(indexPath.row)
        
        // Segue to Story Detail screen, this screen doesn't have associated nib or storyboard
        
        let viewModel = StoryDetailViewModel(pageUrl: model.url, screenTitle: "Story")
        let viewController = StoryDetailViewController()
        viewController.viewModel = viewModel
        viewModel.delegate = viewController
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    
    override func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return NewsFeedTableViewCell.height
    }
}

// MARK: - View Model Callbacks

extension StoryListViewController: StoryListActions {
    func refreshingFeed(status: Bool) {
        self.refreshControl?.endRefreshing()
        
        if status == true {
            self.spinner.start(onView: self.view)
        }
        else {
            self.spinner.stop()
        }
    }
    
    func updateNewsFeed(_ feed: [StoryListViewModel.NewsViewModel]) {
        self.tableView.reloadData()
    }
    
    func errorOccured(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: UIAlertControllerStyle.alert)
        let button = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil)
        alertController.addAction(button)
        
        self.present(alertController, animated: true, completion: nil)
    }
}

class NewsFeedTableViewCell: UITableViewCell {
    
    static let height: CGFloat = 158.5
    
    internal let spinner = Spinner()

    @IBOutlet weak var thumbnail: UIImageView!
    @IBOutlet weak var headline: UILabel!
    @IBOutlet weak var abstract: UILabel!
    @IBOutlet weak var line: UILabel!
    
    func configure(viewModel: StoryListViewModel.NewsViewModel) {
        
        self.thumbnail.image = nil // reset reusable cell's image
        
        if viewModel.hasImage { // unhide and download image for image view
            self.thumbnail.isHidden = false
            self.spinner.start(onView: self.thumbnail)
            viewModel.downloadImage(callback: { [weak self] (image) in
              self?.spinner.stop()
              self?.thumbnail.image = image
            })
        }
        else { // no image available, hide image view
            self.thumbnail.isHidden = true
        }
        
        self.headline.text = viewModel.headline
        self.abstract.text = viewModel.abstract
        self.line.text = viewModel.line
    }
}
