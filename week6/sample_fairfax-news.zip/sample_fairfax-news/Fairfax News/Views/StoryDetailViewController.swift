//
//  StoryDetailViewController.swift
//  Fairfax News
//
//  Created by Faiq Kazi on 19/8/17.
//  Copyright © 2017 Faiq Kazi. All rights reserved.
//

import UIKit

import WebKit
import SafariServices

class StoryDetailViewController: UIViewController {

    var viewModel: StoryDetailViewModel!
    internal let spinner = Spinner()
    
    internal var webview: WKWebView?
    
    internal var isViewDisappearing = false // this is to ignore errors if view is dissappearing
    
    override func loadView() {
        
        // enable javascript
        let preferences = WKPreferences()
        preferences.javaScriptEnabled = true
        
        let configuration = WKWebViewConfiguration()
        configuration.preferences = preferences
      
        webview = WKWebView(frame: .zero, configuration:configuration)
        webview?.uiDelegate = self
        webview?.navigationDelegate = self
        
        view = webview
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.isViewDisappearing = false
        
        self.title = self.viewModel.screenTitle
        
        self.viewModel.viewDidLoad()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.isViewDisappearing = true
        
        self.webview?.stopLoading() // cancel pending request
    }
}

// MARK: - Web view Callbacks

extension StoryDetailViewController: WKUIDelegate {
    
    func webViewDidClose(_ webView: WKWebView) {
    }
}

extension StoryDetailViewController: WKNavigationDelegate {
    
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        self.viewModel.pageDidTerminate()
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        self.viewModel.pageLoadError(error)
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        self.viewModel.pageWillLoad()
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        self.viewModel.pageDidLoad()
    }
}

// MARK: - View Model Callbacks

extension StoryDetailViewController: StoryDetailActions {
    func pageLoading(status: Bool) {
        if status == true {
            self.spinner.start(onView: self.webview!)
        }
        else {
            self.spinner.stop()
        }
    }
    
    func loadUrl(_ url: URLRequest) {
        _ = self.webview?.load(url)
    }
    
    func errorOccured(message: String) {
        if self.isViewDisappearing {
            return // ignore errors if view is dissapearing
        }
        
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: UIAlertControllerStyle.alert)
        let button = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil)
        alertController.addAction(button)
        
        self.present(alertController, animated: true, completion: nil)
    }

}
