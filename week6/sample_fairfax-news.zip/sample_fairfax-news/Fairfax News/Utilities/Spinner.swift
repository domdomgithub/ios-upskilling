//
//  Spinner.swift
//  Fairfax News
//
//  Created by Faiq Kazi on 19/8/17.
//  Copyright © 2017 Faiq Kazi. All rights reserved.
//

import Foundation
import UIKit

public class Spinner : UIViewController {
    
    public static func Start(onView containerView :UIView) -> Spinner {
        let spinner = Spinner()
        spinner.start(onView: containerView)
        return spinner
    }
    
    public func start(onView containerView :UIView) {
        containerView.addSubview(self.view)
    }
    
    public func stop() {
        self.view.removeFromSuperview()
    }
    
    override public func loadView() {
        super.loadView()
        
        let screenSize: CGRect = UIScreen.main.bounds
        let baseView = UIView(frame: screenSize)
        baseView.backgroundColor = UIColor.clear
        self.view = baseView
        
        let progressIcon = UIActivityIndicatorView()
        progressIcon.translatesAutoresizingMaskIntoConstraints = false
        progressIcon.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.whiteLarge
        view.addSubview(progressIcon)
        progressIcon.startAnimating()
        progressIcon.color = UIColor.darkGray
        
        var constraints = [NSLayoutConstraint]()
        constraints.append(NSLayoutConstraint(
            item: progressIcon,
            attribute: .centerX,
            relatedBy: .equal,
            toItem: view,
            attribute: .centerX,
            multiplier: 1,
            constant: 0)
        )
        constraints.append(NSLayoutConstraint(
            item: progressIcon,
            attribute: .centerY,
            relatedBy: .equal,
            toItem: view,
            attribute: .centerY,
            multiplier: 1,
            constant: 0)
        )
        
        view.addConstraints(constraints)
    }
}
