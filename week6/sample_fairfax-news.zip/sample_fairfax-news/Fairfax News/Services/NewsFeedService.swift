//
//  NewsFeedService.swift
//  Fairfax News
//
//  Created by Faiq Kazi on 19/8/17.
//  Copyright © 2017 Faiq Kazi. All rights reserved.
//

import Foundation

import Alamofire        // for network data downloads
import Mapper           // for json to object mapping
import AlamofireImage   // for image download and caching

enum NewsFeedError: Error {
    case invalidData(String)
    case objectSerialization(String)
}

class NewsFeedService {
    open static let sharedInstance = NewsFeedService()
    
    internal let noCachePolicy: Alamofire.SessionManager = {
        let configuration = URLSessionConfiguration.default
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        return SessionManager(configuration: configuration)
    }()

    func feed(success: @escaping (AssetList) -> Void, failure: @escaping (NewsFeedError) -> Void) {        
        noCachePolicy.request("https://bruce-v2-mob.fairfaxmedia.com.au/1/coding_test/13ZZQX/full").responseJSON { response in
            
            if let json = response.result.value {
                
                // map response json dictionary to AssetList / Mapper
                if let jsonDictionary = json as? NSDictionary {
                    if let assetList = try? AssetList(map: Mapper(JSON: jsonDictionary)) {
                        debugPrint(assetList)
                        
                        success(assetList)
                        return
                    }
                }
                failure(.objectSerialization("error mapping json to object, unexpected error"))
            }
            else {
                failure(.invalidData("error fetching data, please check your network connection"))
            }
        }
    }
    
    internal let imageDownloader = ImageDownloader(
        configuration: ImageDownloader.defaultURLSessionConfiguration(),
        downloadPrioritization: .fifo,
        maximumActiveDownloads: 4,
        imageCache: AutoPurgingImageCache()
    )
    
    func downloadImage(url: String, callback: @escaping (UIImage?) -> Void) {
        let urlRequest = URLRequest(url: URL(string: url)!)
        
        imageDownloader.download(urlRequest) { response in
            debugPrint(response.request ?? "-cached-")
            debugPrint(response.response ?? "-cached-")
            debugPrint(response.result)
            
            if let image = response.result.value {
                image.af_inflate()
                callback(image)
            }
            else {
                callback(nil) // denotes download errored
            }
        }
    }
}

