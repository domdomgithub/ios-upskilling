//
//  AssetArticle.swift
//  Fairfax News
//
//  Created by Faiq Kazi on 20/8/17.
//  Copyright © 2017 Faiq Kazi. All rights reserved.
//

import Foundation

/**
 * using Mapper for json dictionary to object mapping -- Mapper is relatively new object mapping library
 * other possible solutions are;
 *  passing [String:Any] to init and mapping through dictionary
 *  using library bundle Argo, Curry, Runes; comparative to Mapper, this adds extraneous binary size and mapping runtime is slower
 *  using library ObjectMapper; comparative to Mapper, the mapping process is not in initializer, forcing variables to be var optionals
 *  swift 4 has better object mapping (JSONEncoder/JSONDecoder) there might be no need of 3rd party library here in future
 **/
import Mapper


struct AssetArticle: Mappable {
    let id: Int
    let url: String
    let headline: String
    let theAbstract: String
    let byLine: String
    let timeStamp: TimeInterval
    
    let relatedImages: [AssetImage]
    
    init(map: Mapper) throws {
        try id = map.from("id")
        try url = map.from("url")
        try headline = map.from("headline")
        try theAbstract = map.from("theAbstract")
        try byLine = map.from("byLine")
        try timeStamp = map.from("timeStamp")
        
        relatedImages = map.optionalFrom("relatedImages") ?? []
    }
}
